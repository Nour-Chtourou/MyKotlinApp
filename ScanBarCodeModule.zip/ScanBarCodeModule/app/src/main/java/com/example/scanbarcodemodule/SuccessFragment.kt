package com.example.scanbarcodemodule

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.scanbarcodemodule.databinding.FragmentSuccessBinding

class SuccessFragment : Fragment(){
    private var _binding: FragmentSuccessBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSuccessBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("SuspiciousIndentation")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    val safeArgs: SuccessFragmentArgs by navArgs()
    val code = safeArgs.code
        binding.btn.setOnClickListener{
        findNavController().navigateUp()
    }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}