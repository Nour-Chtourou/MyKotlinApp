package com.example.sqlitedatabase
import java.io.File
class ConnectionClass {
    companion object {
        var myFile: File? = null
    }
}