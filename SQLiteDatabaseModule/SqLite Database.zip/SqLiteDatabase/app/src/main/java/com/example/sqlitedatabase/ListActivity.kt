package com.example.sqlitedatabase

import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.sqlitedatabase.databinding.ActivityListBinding
import java.io.File
class ListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListBinding
    private lateinit var dbHelper: DatabaseHelper
    private var db:SQLiteDatabase? = null
    private var myFile: File? = null
    private lateinit var itemArrayList: ArrayList<DataSet>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        myFile = ConnectionClass.myFile
        dbHelper = DatabaseHelper(this)
        db = dbHelper.readableDatabase
        binding.ItmList.layoutManager = LinearLayoutManager(this)
        itemArrayList = arrayListOf()

        showDataList()
    }

    override fun onResume() {
        super.onResume()
        itemArrayList.clear()
        showDataList()
    }

    private fun showDataList() {
        try {
            val cursor = db!!.rawQuery("SELECT * FROM product", null)
            if (cursor.count > 0) {
                while (cursor.moveToNext()) {
                    val pId = cursor.getInt(cursor.getColumnIndexOrThrow("productId"))
                    val name = cursor.getString(cursor.getColumnIndexOrThrow("productName"))
                    val price = cursor.getDouble(cursor.getColumnIndexOrThrow("productPrice"))
                    val x = cursor.getBlob(cursor.getColumnIndexOrThrow("productCode")) ?: byteArrayOf(0x00)
                    val itemDS = DataSet(pId, name,price, x)
                    itemArrayList.add(itemDS)
                }
                cursor.close()

                val adapter = ItmAdapter(itemArrayList)
                binding.ItmList.adapter = adapter
                val actionType = intent.getStringExtra("msg") ?: ""
                adapter.setOnItemClickListener(object : ItmAdapter.OnItemClickListener {
                    override fun onItemClick(position: Int) {
                        val selectedProduct = itemArrayList[position]
                        val pId = selectedProduct.productID
                        when (actionType) {
                            "delete" -> {
                                db!!.execSQL("DELETE FROM product WHERE productId=$pId")
                                Toast.makeText(
                                    this@ListActivity,
                                    "Item deleted",
                                    Toast.LENGTH_SHORT
                                ).show()
                                itemArrayList.clear()
                                showDataList()
                            }

                            "update" -> {
                                val i = Intent(this@ListActivity, Product::class.java)
                                i.putExtra("msg", "edit")
                                i.putExtra("pid", pId)
                                startActivity(i)
                            }

                            else -> {

                                val i = Intent(this@ListActivity, Product::class.java)
                                i.putExtra("msg", "view")
                                i.putExtra("pid", pId)
                                startActivity(i)
                            }
                        }
                    }
                })
            }
        } catch (ex: Exception) {
            Toast.makeText(this, ex.message.toString(), Toast.LENGTH_SHORT).show()
        }
    }
}
