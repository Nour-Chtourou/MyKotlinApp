package com.example.sqlitedatabase

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.sqlitedatabase.databinding.ActivityMainBinding
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var db: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize DBHelper
        dbHelper = DatabaseHelper(this)
        db = dbHelper.writableDatabase // Get writable database

        // View List Button
        binding.btnUpdate.setOnClickListener {
            startActivity(Intent(this, ListActivity::class.java))
        }
    }

    // Add a new product
    fun addData(view: View) {
        val intent = Intent(this, Product::class.java)
        intent.putExtra("msg", "add")
        startActivity(intent)
    }

    // Edit a selected product
    fun editData(view: View) {
        val intent = Intent(this, ListActivity::class.java)
        intent.putExtra("msg", "edit") // Pass edit mode
        startActivity(intent)
    }

    // Delete a product
    fun deleteData(view: View) {
        val intent = Intent(this, ListActivity::class.java)
        intent.putExtra("msg", "delete")  // Indicate delete mode
        startActivity(intent)
    }
}
