package com.example.sqlitedatabase

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.sqlitedatabase.databinding.ActivityProductBinding
import java.io.ByteArrayOutputStream
import java.io.File

class Product : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    private var db: SQLiteDatabase? = null
    private lateinit var binding: ActivityProductBinding
    private var imageByteArray: ByteArray? = null
    private var myFile: File? = null
    private lateinit var msg: String
    private var pId:Int = 0
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityProductBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        dbHelper = DatabaseHelper(this)
        db = dbHelper.writableDatabase
        myFile =ConnectionClass.myFile
        val dbPath = getDatabasePath("mydatabase.db").absolutePath
        db= SQLiteDatabase.openOrCreateDatabase(dbPath,null,null)
        val i = intent
        msg = i.getStringExtra("msg").toString()
        pId = i.getIntExtra("pid", 0)
        when(msg){
            "add"-> {
                binding.btnSave.text = "Insert Data"
                binding.btnDel.visibility = View.GONE
                binding.btnEdit.visibility = View.GONE
            }
            "edit"-> {
                binding.btnSave.text = "Update Data"
                binding.btnDel.visibility = View.GONE
                binding.btnEdit.visibility = View.VISIBLE
                showData()

            }
            "view" -> {
                binding.btnSave.visibility = View.GONE
                binding.btnDel.visibility = View.GONE
                binding.btnEdit.visibility = View.VISIBLE

                showData()
            }
        }
    }
    fun uploadProductCode(view : View){
        val myFileIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type= "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        activityResultLauncher.launch(myFileIntent)

    }
    private val activityResultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ){ result ->
        if (result.resultCode == Activity.RESULT_OK){
            val data: Intent? = result.data
            val uri: Uri? = data?.data
            if ( uri != null)
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val inputStream= contentResolver.openInputStream(uri)
                val myBitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                if (myBitmap!= null){
                    val stream = ByteArrayOutputStream()
                myBitmap.compress(Bitmap.CompressFormat.PNG, 100 , stream)
                    imageByteArray = stream.toByteArray()
                    stream.close()
                binding.imageView.setImageBitmap(myBitmap)
            }
                else{
                    Log.e("BitmapError", "Failed to decode bitmap")
                }
            }
            catch (ex: java.lang.Exception){
                Toast.makeText(this, ex.message.toString(), Toast.LENGTH_LONG).show()
            }
        }
    }
    private fun insertData(){
        val pName = binding.edtName.text.toString()
        val pPrice = binding.edtPrice.text.toString().toDoubleOrNull() ?: 0.0
        if (binding.edtName.text.toString().isEmpty())
        {
            Toast.makeText(this, "Input product Name", Toast.LENGTH_SHORT).show()
            binding.edtName.requestFocus()
            return
        }
        if (binding.edtPrice.text.toString().isEmpty())
        {
            Toast.makeText(this, "Input product Price", Toast.LENGTH_SHORT).show()
            binding.edtPrice.requestFocus()
            return
        }

            try {

                 val values = ContentValues()
                values.put("productName", pName)
                values.put("productPrice", pPrice)
                values.put("productCode", imageByteArray?: byteArrayOf())
                db!!.insert("product", null, values)
                Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, ListActivity::class.java)
                startActivity(intent)
                finish()
                clr()


            }
            catch (ex:Exception){
                Toast.makeText(this, "insert:" + ex.message.toString(), Toast.LENGTH_LONG).show()
            }

    }
    fun updateData(view:View) {
        val pName = binding.edtName.text.toString()
        val pPrice = binding.edtPrice.text.toString().toDoubleOrNull() ?: 0.0
        if (binding.edtName.text.toString().isEmpty()) {
            Toast.makeText(this, "Input product Name", Toast.LENGTH_SHORT).show()
            binding.edtName.requestFocus()
            return
        }
        if (binding.edtPrice.text.toString().isEmpty()) {
            Toast.makeText(this, "Input product Price", Toast.LENGTH_SHORT).show()
            binding.edtPrice.requestFocus()
            return
        }
            try {
                val values = ContentValues()
                values.put("productName", pName)
                values.put("productPrice", pPrice)
                if (imageByteArray != null){
                    values.put("productCode", imageByteArray)
                }
                val rowsUpdated = db!!.update("product", values, "productId=?", arrayOf(pId.toString()))
                if (rowsUpdated >0) {
                    Toast.makeText(this, "Data Updated", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Update Failed", Toast.LENGTH_SHORT).show()
                }
                val intent = Intent(this, ListActivity::class.java)
                startActivity(intent)
                finish()


            } catch (ex: Exception) {
                Toast.makeText(this, "insert:" + ex.message.toString(), Toast.LENGTH_LONG).show()
            }
            Log.d("ProductActivity", "Received pId: $pId")


    }
    private fun clr(){
        binding.edtName.text.clear()
        binding.edtPrice.text.clear()
        binding.imageView.setImageBitmap(null)
        imageByteArray = null
    }
    fun btnClick(view: View){
        when(msg){
            "add" -> insertData()
            "edit" -> updateData(view)
        }

    }
    fun delData(view: View){
        db!!.delete("product", "productId=?", arrayOf(pId.toString()))
        Toast.makeText(this, "Data Deleted ", Toast.LENGTH_SHORT).show()
        val intent = Intent(this, ListActivity::class.java)
        intent.putExtra("msg", "delete")
        startActivity(intent)
        finish()
    }
    @SuppressLint("SetTextI18n")
    private fun showData(){
        try {
            val cursor = db!!.rawQuery("SELECT * FROM product WHERE productId = $pId", null)
            if (cursor.count>0) {
                while (cursor.moveToNext()) {
                    binding.edtName.setText(cursor.getString(1))
                    binding.edtPrice.setText(cursor.getDouble(2).toString())
                    val x = cursor.getBlob(3)
                    if (x != null) {
                        val bitmap = BitmapFactory.decodeByteArray(x, 0, x.size)
                        imageByteArray = x
                        binding.imageView.setImageBitmap(bitmap)
                    }
                }
                cursor.close()
            }
        } catch (ex:Exception){
            Toast.makeText(this, ex.message.toString(), Toast.LENGTH_SHORT).show()
        }

    }
}