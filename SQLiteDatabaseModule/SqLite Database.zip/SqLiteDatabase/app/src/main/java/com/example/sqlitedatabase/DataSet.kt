package com.example.sqlitedatabase

data class DataSet(
    val productID: Int,
    val productName: String,
    val productPrice: Double,
    val img:ByteArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as DataSet

        if (productID != other.productID) return false
        if (productName != other.productName) return false
        if (productPrice!= other.productPrice) return false
        if (!img.contentEquals(other.img)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = productID
        result = 31 * result + productName.hashCode()
        result = 31 * result + productPrice.hashCode()
        result = 31 * result + img.contentHashCode()
        return result
    }
}
